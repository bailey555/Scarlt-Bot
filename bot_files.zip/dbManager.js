// dbManager.js
const fs = require('fs');
const path = require('path');

const baseDir = path.join(__dirname, 'database');

if (!fs.existsSync(baseDir)) {
    fs.mkdirSync(baseDir);
}

module.exports = {
    read(fileName) {
        const filePath = path.join(baseDir, fileName);
        if (!fs.existsSync(filePath)) return null;

        try {
            const data = fs.readFileSync(filePath, 'utf8');
            return JSON.parse(data);
        } catch (err) {
            console.error('Erro ao ler JSON:', err);
            return null;
        }
    },

    write(fileName, data) {
        const filePath = path.join(baseDir, fileName);
        try {
            fs.writeFileSync(filePath, JSON.stringify(data, null, 2));
            return true;
        } catch (err) {
            console.error('Erro ao salvar JSON:', err);
            return false;
        }
    },

    update(fileName, callback) {
        const data = this.read(fileName) || {};
        const updated = callback(data);
        this.write(fileName, updated);
        return updated;
    }
};
